function makebet(element) {
    var betValue = element.textContent
    document.getElementById('bet').value = betValue
}
